export default {}
export const API_URL = 'https://conduit.productionready.io/api'
